package com.example.githubuser.data.retrofit
import com.example.githubuser.data.response.DetailUserResponse
import com.example.githubuser.data.response.MainResponse
import com.example.githubuser.data.response.User
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("search/users")
    @Headers("Authorization: token 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")
    fun searchUsers(
        @Query("q") q: String
    ): Call<MainResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getUserDetail(
        @Path("username") username: String
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getUserFollowers(
        @Path("username") username: String
    ): Call<ArrayList<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getUserFollowing(
        @Path("username") username: String
    ): Call<ArrayList<User>>

}