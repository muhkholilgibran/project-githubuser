package com.example.githubuser.data.ui

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.githubuser.R
import com.example.githubuser.data.adapter.SectionsPagerAdapter
import com.example.githubuser.data.util.HelpResult
import com.example.githubuser.databinding.ActivityDetailBinding
import kotlinx.coroutines.launch


class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_ID = "extra_id"
        const val EXTRA_NAME = "extra_name"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }

    private lateinit var binding: ActivityDetailBinding
    private lateinit var detailViewModel: AllViewModels

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = intent.getStringExtra(EXTRA_USERNAME)
        if (username.isNullOrEmpty()) {
            finish()
            return
        }

        val bundle = Bundle().apply {
            putString(EXTRA_USERNAME, username)
        }

        setupViewModel()
        observeDetailUser()
        setupViewPager(bundle)
    }

    private fun setupViewModel() {
        detailViewModel = ViewModelProvider(this)[AllViewModels::class.java]
        lifecycleScope.launch {
            detailViewModel.setDetailUsers(intent.getStringExtra(EXTRA_USERNAME)!!)
        }
    }

    private fun observeDetailUser() {
        detailViewModel.detailUser().observe(this) { detailUser ->
            if (detailUser != null) {
                with(binding) {
                    Name.text = detailUser.name
                    Username.text = detailUser.login
                    detailFollowers.text = "${detailUser.followers} Pengikut"
                    detailFollowing.text = "${detailUser.following} Mengikuti"
                    Glide.with(this@DetailActivity)
                        .load(detailUser.avatarUrl)
                        .centerCrop()
                        .into(ImgProfile)
                    showLoading(false)
                }
            }
        }
    }

    private fun setupViewPager(bundle: Bundle) {
        val sectionPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager, bundle)
        binding.viewPager.adapter = sectionPagerAdapter
        binding.tabs.setupWithViewPager(binding.viewPager)

        for (i in TAB_TITLES.indices) {
            binding.tabs.getTabAt(i)?.setText(TAB_TITLES[i])
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.LoadingDetail.visibility = if (isLoading) {
            View.VISIBLE
            Log.d("DetailActivity", "showLoading: $isLoading")
        } else {
            View.GONE
        }
    }


}


