package com.example.githubuser.data.ui


import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.data.adapter.ListUserAdapter
import com.example.githubuser.data.response.User
import com.example.githubuser.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: AllViewModels
    private lateinit var listAdapter: ListUserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(AllViewModels::class.java)

        setupUI()
        observeUserData()

    }

    private fun setupUI() {
        listAdapter = ListUserAdapter()
        listAdapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(user: User) {
                navigateToUserDetail(user)
            }
        })

        binding.apply {
            ResultSearch.layoutManager = LinearLayoutManager(this@MainActivity)
            ResultSearch.setHasFixedSize(true)
            ResultSearch.adapter = listAdapter

            btnSearch.setOnClickListener {
                val query = Search.text.toString()
                if (query.isNotEmpty()) {
                    showLoading(true)
                    viewModel.searchUsers(query)
                }
            }

            Search.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                    val query = Search.text.toString()
                    if (query.isNotEmpty()) {
                        showLoading(true)
                        viewModel.searchUsers(query)
                    }
                    return@setOnKeyListener true
                }
                return@setOnKeyListener false
            }
        }
    }

    private fun observeUserData() {
        viewModel.users().observe(this) { users ->
            listAdapter.updateData(users)
            showLoading(false)
        }

    }

    private fun navigateToUserDetail(user: User) {
        val intent = Intent(this, DetailActivity::class.java).apply {
            putExtra(DetailActivity.EXTRA_USERNAME, user.login)
            putExtra(DetailActivity.EXTRA_NAME, user.name)
            putExtra(DetailActivity.EXTRA_ID, user.id)
        }
        startActivity(intent)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.ProgressLoading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

}
